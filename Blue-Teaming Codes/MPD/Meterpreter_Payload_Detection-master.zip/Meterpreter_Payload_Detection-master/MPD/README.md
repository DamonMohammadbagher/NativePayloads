# Meterpreter Payload Detection MPD

Using ETW for Detecting Meterpreter Processes/Threads by C# (.NET framework 4.5) 

----------------------
Note: in this New Article i talked about how an attacker can Bypass this Code Sometimes with Code Chunking Technique.

    New Article: 
    Detecting Thread Injection by ETW & One Simple Technique [ https://damonmohammadbagher.github.io/Posts/7jun2020x.html ]
    

-------------------------
1. ETWMonThread.cs , Simple C# Source Code with ETW Sample for Detecting Injected Meterpreter Payloads via Thread Injection Method (only) , Video : https://www.youtube.com/watch?v=nIoDrqeQ2es

Note: RunAs Admin "Required"
-------------------------
