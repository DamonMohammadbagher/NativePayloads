# MPD  Meterpreter_Payload_Detection.exe Tool

C# code Author                : Damon Mohammadbagher

Meterpreter Signature Authors : Rohan Vazarkar, David Bitner

Note : some API programming and Meterpreter Signature Created by these guys Rohan Vazarkar, David Bitner , not by me . 

i just made console version of code by C# and develop this Code by some API Functions. 

Please don't ask me about Signature and Source code.

but i hope my application was useful for you all guys and i hope you all help me to make better versions for this code in future.

thank you all .

Note : IPS Mode required RunAs Administrators

if you getting error , use command with one argument 

syntax : Meterpreter_Payload_Detection.exe IPS

syntax : Meterpreter_Payload_Detection.exe IDS

syntax : Meterpreter_Payload_Detection.exe Blobblob


Video Published by Damon Mohammadbagher (bbxc9x00x1f)


Video for Meterpreter_Payload_Detection.exe Tool

Video 1 : https://youtu.be/Ka9c_d3sR_k

Bypassing AVs with NativePayload_DNS and Meterpreter_Payload_Detection

Video 2 : https://youtu.be/ngZl4PSfW6o

Video Description: Bypassing AVs with NativePayload_DNS.exe and Detecting Meterpreter Process by Meterpreter_Payload_Detection tool


step by step and for more information Please visit this link:

Detecting Meterpreter Undetectable Payloads by Scanning Memory
https://www.linkedin.com/pulse/detecting-meterpreter-undetectable-payloads-scanning-mohammadbagher?trk=pulse_spock-articles

Related Links : 

Bypass all anti-viruses by Encrypted Payloads with C#
https://www.linkedin.com/pulse/bypass-all-anti-viruses-encrypted-payloads-c-damon-mohammadbagher?trk=pulse_spock-articles

### ETWMonThread
Download Link => https://github.com/DamonMohammadbagher/Meterpreter_Payload_Detection/tree/master/MPD/ETWMonThread

![](https://github.com/DamonMohammadbagher/Meterpreter_Payload_Detection/blob/master/MPD/ETWMonThread/ETWMonThread.png)


<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/Meterpreter_Payload_Detection"/></a></p>
