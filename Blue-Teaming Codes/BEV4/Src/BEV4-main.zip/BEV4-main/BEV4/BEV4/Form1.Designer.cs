﻿namespace BEV4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }
            catch (System.Exception)
            {

            }
          
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_Nodes = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel9 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.remoteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton6 = new System.Windows.Forms.ToolStripDropDownButton();
            this.propertiesWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.relaodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton5 = new System.Windows.Forms.ToolStripDropDownButton();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reloadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.filterByEventTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterByMessageTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherFiltersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton7 = new System.Windows.Forms.ToolStripDropDownButton();
            this.startRealtimeMonitorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopMonitorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showLogsAllDetectionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.realtimeScanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scanningFastToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scanningArgsSlowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.searchHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton8 = new System.Windows.Forms.ToolStripDropDownButton();
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton4 = new System.Windows.Forms.ToolStripDropDownButton();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutBEVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.Local_contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.reloadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.saveThisEventToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.filteringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterByEventTypesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.filterByMessageTextToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.treeView2 = new System.Windows.Forms.TreeView();
            this.Remote_contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveThisEventToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.filterThisEventToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterByTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterByMessageTextToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Datagrid1_2ContexMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.propertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Datagrid3_4ContexMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.propertiesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.statusStrip9 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel11 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.statusStrip3 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.statusStrip5 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.loadHistoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveHistoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.statusStrip4 = new System.Windows.Forms.StatusStrip();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.listView2 = new System.Windows.Forms.ListView();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.richTextBox35 = new System.Windows.Forms.RichTextBox();
            this.statusStrip8 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel10 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage40 = new System.Windows.Forms.TabPage();
            this.richTextBox36 = new System.Windows.Forms.RichTextBox();
            this.tabPage41 = new System.Windows.Forms.TabPage();
            this.richTextBox37 = new System.Windows.Forms.RichTextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.splitContainer15 = new System.Windows.Forms.SplitContainer();
            this.treeView4 = new System.Windows.Forms.TreeView();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.richTextBox34 = new System.Windows.Forms.RichTextBox();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.richTextBox21 = new System.Windows.Forms.RichTextBox();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.richTextBox22 = new System.Windows.Forms.RichTextBox();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.richTextBox23 = new System.Windows.Forms.RichTextBox();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.richTextBox24 = new System.Windows.Forms.RichTextBox();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.richTextBox25 = new System.Windows.Forms.RichTextBox();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.richTextBox26 = new System.Windows.Forms.RichTextBox();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.richTextBox27 = new System.Windows.Forms.RichTextBox();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.richTextBox28 = new System.Windows.Forms.RichTextBox();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.richTextBox29 = new System.Windows.Forms.RichTextBox();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.richTextBox30 = new System.Windows.Forms.RichTextBox();
            this.tabPage37 = new System.Windows.Forms.TabPage();
            this.richTextBox31 = new System.Windows.Forms.RichTextBox();
            this.tabPage38 = new System.Windows.Forms.TabPage();
            this.richTextBox32 = new System.Windows.Forms.RichTextBox();
            this.tabPage39 = new System.Windows.Forms.TabPage();
            this.richTextBox33 = new System.Windows.Forms.RichTextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.splitContainer14 = new System.Windows.Forms.SplitContainer();
            this.treeView3 = new System.Windows.Forms.TreeView();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.richTextBox14 = new System.Windows.Forms.RichTextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.richTextBox15 = new System.Windows.Forms.RichTextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.richTextBox19 = new System.Windows.Forms.RichTextBox();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.richTextBox20 = new System.Windows.Forms.RichTextBox();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.Local_contextMenuStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.Remote_contextMenuStrip2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.Datagrid1_2ContexMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.Datagrid3_4ContexMenu.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.statusStrip9.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.statusStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.statusStrip5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.statusStrip8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.groupBox19.SuspendLayout();
            this.tabPage40.SuspendLayout();
            this.tabPage41.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).BeginInit();
            this.splitContainer15.Panel1.SuspendLayout();
            this.splitContainer15.Panel2.SuspendLayout();
            this.splitContainer15.SuspendLayout();
            this.tabControl8.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).BeginInit();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.tabPage29.SuspendLayout();
            this.tabPage30.SuspendLayout();
            this.tabPage31.SuspendLayout();
            this.tabPage32.SuspendLayout();
            this.tabPage33.SuspendLayout();
            this.tabPage34.SuspendLayout();
            this.tabPage35.SuspendLayout();
            this.tabPage36.SuspendLayout();
            this.tabPage37.SuspendLayout();
            this.tabPage38.SuspendLayout();
            this.tabPage39.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).BeginInit();
            this.splitContainer14.Panel1.SuspendLayout();
            this.splitContainer14.Panel2.SuspendLayout();
            this.splitContainer14.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_Nodes,
            this.toolStripStatusLabel9,
            this.toolStripProgressBar1,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 442);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(950, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_Nodes
            // 
            this.toolStripStatusLabel_Nodes.Name = "toolStripStatusLabel_Nodes";
            this.toolStripStatusLabel_Nodes.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel9
            // 
            this.toolStripStatusLabel9.Name = "toolStripStatusLabel9";
            this.toolStripStatusLabel9.Size = new System.Drawing.Size(214, 17);
            this.toolStripStatusLabel9.Text = "| MITRE ATTACK Realtime Monitor is off";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton6,
            this.toolStripDropDownButton2,
            this.toolStripDropDownButton5,
            this.toolStripDropDownButton3,
            this.toolStripDropDownButton7,
            this.toolStripDropDownButton8,
            this.toolStripDropDownButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(950, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(38, 22);
            this.toolStripDropDownButton1.Text = "&File";
            this.toolStripDropDownButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.localToolStripMenuItem,
            this.remoteToolStripMenuItem});
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // localToolStripMenuItem
            // 
            this.localToolStripMenuItem.Name = "localToolStripMenuItem";
            this.localToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.localToolStripMenuItem.Text = "Local System";
            this.localToolStripMenuItem.Click += new System.EventHandler(this.localToolStripMenuItem_Click);
            // 
            // remoteToolStripMenuItem
            // 
            this.remoteToolStripMenuItem.Name = "remoteToolStripMenuItem";
            this.remoteToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.remoteToolStripMenuItem.Text = "Remote System";
            this.remoteToolStripMenuItem.Click += new System.EventHandler(this.remoteToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton6
            // 
            this.toolStripDropDownButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.propertiesWindowToolStripMenuItem});
            this.toolStripDropDownButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton6.Image")));
            this.toolStripDropDownButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton6.Name = "toolStripDropDownButton6";
            this.toolStripDropDownButton6.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton6.Text = "View";
            // 
            // propertiesWindowToolStripMenuItem
            // 
            this.propertiesWindowToolStripMenuItem.Name = "propertiesWindowToolStripMenuItem";
            this.propertiesWindowToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.propertiesWindowToolStripMenuItem.Text = "Properties Window";
            this.propertiesWindowToolStripMenuItem.Click += new System.EventHandler(this.propertiesWindowToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.relaodToolStripMenuItem,
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem,
            this.refreshToolStripMenuItem});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(48, 22);
            this.toolStripDropDownButton2.Text = "&Local";
            this.toolStripDropDownButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // relaodToolStripMenuItem
            // 
            this.relaodToolStripMenuItem.Name = "relaodToolStripMenuItem";
            this.relaodToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.relaodToolStripMenuItem.Text = "Relaod";
            this.relaodToolStripMenuItem.Click += new System.EventHandler(this.relaodToolStripMenuItem_Click);
            // 
            // reloadExportToHTMLCSVViaPowershellToolStripMenuItem
            // 
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem.Name = "reloadExportToHTMLCSVViaPowershellToolStripMenuItem";
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem.Text = "Reload (Export to HTML/CSV via Powershell) , Fast";
            this.reloadExportToHTMLCSVViaPowershellToolStripMenuItem.Click += new System.EventHandler(this.ReloadExportToHTMLCSVViaPowershellToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton5
            // 
            this.toolStripDropDownButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem,
            this.reloadToolStripMenuItem});
            this.toolStripDropDownButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton5.Image")));
            this.toolStripDropDownButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton5.Name = "toolStripDropDownButton5";
            this.toolStripDropDownButton5.Size = new System.Drawing.Size(61, 22);
            this.toolStripDropDownButton5.Text = "&Remote";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // reloadToolStripMenuItem
            // 
            this.reloadToolStripMenuItem.Name = "reloadToolStripMenuItem";
            this.reloadToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.reloadToolStripMenuItem.Text = "Reload";
            this.reloadToolStripMenuItem.Click += new System.EventHandler(this.reloadToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filterByEventTypesToolStripMenuItem,
            this.filterByMessageTextToolStripMenuItem,
            this.otherFiltersToolStripMenuItem});
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(51, 22);
            this.toolStripDropDownButton3.Text = "&Filters";
            this.toolStripDropDownButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            // 
            // filterByEventTypesToolStripMenuItem
            // 
            this.filterByEventTypesToolStripMenuItem.Name = "filterByEventTypesToolStripMenuItem";
            this.filterByEventTypesToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.filterByEventTypesToolStripMenuItem.Text = "Filter by Event Types";
            this.filterByEventTypesToolStripMenuItem.Click += new System.EventHandler(this.filterByEventTypesToolStripMenuItem_Click);
            // 
            // filterByMessageTextToolStripMenuItem
            // 
            this.filterByMessageTextToolStripMenuItem.Name = "filterByMessageTextToolStripMenuItem";
            this.filterByMessageTextToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.filterByMessageTextToolStripMenuItem.Text = "Filter by Message Text";
            this.filterByMessageTextToolStripMenuItem.Click += new System.EventHandler(this.filterByMessageTextToolStripMenuItem_Click);
            // 
            // otherFiltersToolStripMenuItem
            // 
            this.otherFiltersToolStripMenuItem.Name = "otherFiltersToolStripMenuItem";
            this.otherFiltersToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.otherFiltersToolStripMenuItem.Text = "Filters for Security Log";
            this.otherFiltersToolStripMenuItem.Click += new System.EventHandler(this.otherFiltersToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton7
            // 
            this.toolStripDropDownButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startRealtimeMonitorToolStripMenuItem,
            this.stopMonitorToolStripMenuItem,
            this.toolStripMenuItem4,
            this.realtimeScanToolStripMenuItem,
            this.toolStripSeparator3,
            this.searchHistoryToolStripMenuItem,
            this.toolStripSeparator6,
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem,
            this.toolStripSeparator7,
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem});
            this.toolStripDropDownButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton7.Image")));
            this.toolStripDropDownButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton7.Name = "toolStripDropDownButton7";
            this.toolStripDropDownButton7.Size = new System.Drawing.Size(85, 22);
            this.toolStripDropDownButton7.Text = "Mitre Attack";
            // 
            // startRealtimeMonitorToolStripMenuItem
            // 
            this.startRealtimeMonitorToolStripMenuItem.Name = "startRealtimeMonitorToolStripMenuItem";
            this.startRealtimeMonitorToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.startRealtimeMonitorToolStripMenuItem.Text = "Start Monitor";
            this.startRealtimeMonitorToolStripMenuItem.Click += new System.EventHandler(this.StartRealtimeMonitorToolStripMenuItem_Click);
            // 
            // stopMonitorToolStripMenuItem
            // 
            this.stopMonitorToolStripMenuItem.Name = "stopMonitorToolStripMenuItem";
            this.stopMonitorToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.stopMonitorToolStripMenuItem.Text = "Stop Monitor";
            this.stopMonitorToolStripMenuItem.Click += new System.EventHandler(this.StopMonitorToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem,
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem,
            this.showLogsAllDetectionsToolStripMenuItem});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(621, 22);
            this.toolStripMenuItem4.Text = "Real-time Filters";
            // 
            // logsOnlyTruePositivesNotRecommandedToolStripMenuItem
            // 
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem.Name = "logsOnlyTruePositivesNotRecommandedToolStripMenuItem";
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem.Size = new System.Drawing.Size(417, 22);
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem.Text = "Shows/Logs only \"True Positive\" Detections (Not Recommended)";
            this.logsOnlyTruePositivesNotRecommandedToolStripMenuItem.Click += new System.EventHandler(this.LogsOnlyTruePositivesNotRecommandedToolStripMenuItem_Click);
            // 
            // showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem
            // 
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem.Name = "showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem";
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem.Size = new System.Drawing.Size(417, 22);
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem.Text = "Shows/Logs only \"False Positive\" Detections";
            this.showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem.Click += new System.EventHandler(this.ShowsLogsOnlyFalsePositiveDetectionsToolStripMenuItem_Click);
            // 
            // showLogsAllDetectionsToolStripMenuItem
            // 
            this.showLogsAllDetectionsToolStripMenuItem.Checked = true;
            this.showLogsAllDetectionsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showLogsAllDetectionsToolStripMenuItem.Name = "showLogsAllDetectionsToolStripMenuItem";
            this.showLogsAllDetectionsToolStripMenuItem.Size = new System.Drawing.Size(417, 22);
            this.showLogsAllDetectionsToolStripMenuItem.Text = "Shows/Logs All Detections (Default)";
            this.showLogsAllDetectionsToolStripMenuItem.Click += new System.EventHandler(this.ShowLogsAllDetectionsToolStripMenuItem_Click);
            // 
            // realtimeScanToolStripMenuItem
            // 
            this.realtimeScanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.scanningFastToolStripMenuItem,
            this.scanningArgsSlowToolStripMenuItem});
            this.realtimeScanToolStripMenuItem.Name = "realtimeScanToolStripMenuItem";
            this.realtimeScanToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.realtimeScanToolStripMenuItem.Text = "Real-time Scan";
            // 
            // scanningFastToolStripMenuItem
            // 
            this.scanningFastToolStripMenuItem.Checked = true;
            this.scanningFastToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.scanningFastToolStripMenuItem.Name = "scanningFastToolStripMenuItem";
            this.scanningFastToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.scanningFastToolStripMenuItem.Text = "Scanning Fast";
            this.scanningFastToolStripMenuItem.Click += new System.EventHandler(this.ScanningFastToolStripMenuItem_Click);
            // 
            // scanningArgsSlowToolStripMenuItem
            // 
            this.scanningArgsSlowToolStripMenuItem.Name = "scanningArgsSlowToolStripMenuItem";
            this.scanningArgsSlowToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.scanningArgsSlowToolStripMenuItem.Text = "Scanning Args (Slow)";
            this.scanningArgsSlowToolStripMenuItem.Click += new System.EventHandler(this.ScanningArgsSlowToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(618, 6);
            // 
            // searchHistoryToolStripMenuItem
            // 
            this.searchHistoryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveHistoryToolStripMenuItem,
            this.loadHistoryToolStripMenuItem});
            this.searchHistoryToolStripMenuItem.Name = "searchHistoryToolStripMenuItem";
            this.searchHistoryToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.searchHistoryToolStripMenuItem.Text = "Search History";
            // 
            // saveHistoryToolStripMenuItem
            // 
            this.saveHistoryToolStripMenuItem.Name = "saveHistoryToolStripMenuItem";
            this.saveHistoryToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.saveHistoryToolStripMenuItem.Text = "Save History";
            this.saveHistoryToolStripMenuItem.Click += new System.EventHandler(this.SaveHistoryToolStripMenuItem_Click);
            // 
            // loadHistoryToolStripMenuItem
            // 
            this.loadHistoryToolStripMenuItem.Name = "loadHistoryToolStripMenuItem";
            this.loadHistoryToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.loadHistoryToolStripMenuItem.Text = "Load History";
            this.loadHistoryToolStripMenuItem.Click += new System.EventHandler(this.LoadHistoryToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(618, 6);
            // 
            // loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem
            // 
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem.Name = "loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem";
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem.Text = "Load All CmdPrompts (via Atomic-Red-Team [Windows-Index.md] File)";
            this.loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem.Click += new System.EventHandler(this.LoadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(618, 6);
            // 
            // toolStripDropDownButton8
            // 
            this.toolStripDropDownButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem,
            this.toolStripSeparator8,
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem});
            this.toolStripDropDownButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton8.Image")));
            this.toolStripDropDownButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton8.Name = "toolStripDropDownButton8";
            this.toolStripDropDownButton8.Size = new System.Drawing.Size(63, 22);
            this.toolStripDropDownButton8.Text = "Updates";
            // 
            // updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem
            // 
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Name = "updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem";
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Size = new System.Drawing.Size(423, 22);
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Text = "Update Database (via Atomic-Red-Team [Windows-Index.md] file)";
            this.updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Click += new System.EventHandler(this.UpdateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(420, 6);
            // 
            // updateDatabaseviaYourOwnYamlFileToolStripMenuItem
            // 
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem.Name = "updateDatabaseviaYourOwnYamlFileToolStripMenuItem";
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem.Size = new System.Drawing.Size(423, 22);
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem.Text = "Update Database (via your own text file)";
            this.updateDatabaseviaYourOwnYamlFileToolStripMenuItem.Click += new System.EventHandler(this.UpdateDatabaseviaYourOwnYamlFileToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton4
            // 
            this.toolStripDropDownButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem,
            this.aboutBEVToolStripMenuItem});
            this.toolStripDropDownButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton4.Image")));
            this.toolStripDropDownButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton4.Name = "toolStripDropDownButton4";
            this.toolStripDropDownButton4.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton4.Text = "&Help";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // aboutBEVToolStripMenuItem
            // 
            this.aboutBEVToolStripMenuItem.Name = "aboutBEVToolStripMenuItem";
            this.aboutBEVToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.aboutBEVToolStripMenuItem.Text = "About BEV";
            this.aboutBEVToolStripMenuItem.Click += new System.EventHandler(this.aboutBEVToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Silver;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(1, 1);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox6);
            this.splitContainer1.Size = new System.Drawing.Size(938, 386);
            this.splitContainer1.SplitterDistance = 300;
            this.splitContainer1.TabIndex = 2;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.tabControl1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(298, 384);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Events";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(292, 365);
            this.tabControl1.TabIndex = 8;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.treeView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(284, 339);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Local System";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // treeView1
            // 
            this.treeView1.BackColor = System.Drawing.SystemColors.Window;
            this.treeView1.ContextMenuStrip = this.Local_contextMenuStrip1;
            this.treeView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.HideSelection = false;
            this.treeView1.Location = new System.Drawing.Point(3, 3);
            this.treeView1.Name = "treeView1";
            this.treeView1.ShowNodeToolTips = true;
            this.treeView1.Size = new System.Drawing.Size(276, 331);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // Local_contextMenuStrip1
            // 
            this.Local_contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reloadToolStripMenuItem1,
            this.toolStripMenuItem1,
            this.refreshToolStripMenuItem1,
            this.toolStripSeparator2,
            this.saveThisEventToolStripMenuItem,
            this.toolStripSeparator4,
            this.filteringToolStripMenuItem});
            this.Local_contextMenuStrip1.Name = "Local_contextMenuStrip1";
            this.Local_contextMenuStrip1.Size = new System.Drawing.Size(339, 126);
            // 
            // reloadToolStripMenuItem1
            // 
            this.reloadToolStripMenuItem1.Name = "reloadToolStripMenuItem1";
            this.reloadToolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.reloadToolStripMenuItem1.Text = "Reload";
            this.reloadToolStripMenuItem1.Click += new System.EventHandler(this.reloadToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.toolStripMenuItem1.Text = "Reload (Export to HTML/CSV via Powershell) , Fast";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.ToolStripMenuItem1_Click);
            // 
            // refreshToolStripMenuItem1
            // 
            this.refreshToolStripMenuItem1.Name = "refreshToolStripMenuItem1";
            this.refreshToolStripMenuItem1.Size = new System.Drawing.Size(338, 22);
            this.refreshToolStripMenuItem1.Text = "Refresh";
            this.refreshToolStripMenuItem1.Click += new System.EventHandler(this.refreshToolStripMenuItem1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(335, 6);
            // 
            // saveThisEventToolStripMenuItem
            // 
            this.saveThisEventToolStripMenuItem.Name = "saveThisEventToolStripMenuItem";
            this.saveThisEventToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.saveThisEventToolStripMenuItem.Text = "Save This Event";
            this.saveThisEventToolStripMenuItem.Click += new System.EventHandler(this.saveThisEventToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(335, 6);
            // 
            // filteringToolStripMenuItem
            // 
            this.filteringToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filterByEventTypesToolStripMenuItem1,
            this.filterByMessageTextToolStripMenuItem1});
            this.filteringToolStripMenuItem.Name = "filteringToolStripMenuItem";
            this.filteringToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.filteringToolStripMenuItem.Text = "Filter This Event";
            // 
            // filterByEventTypesToolStripMenuItem1
            // 
            this.filterByEventTypesToolStripMenuItem1.Name = "filterByEventTypesToolStripMenuItem1";
            this.filterByEventTypesToolStripMenuItem1.Size = new System.Drawing.Size(189, 22);
            this.filterByEventTypesToolStripMenuItem1.Text = "Filter by Event Types";
            this.filterByEventTypesToolStripMenuItem1.ToolTipText = "Please First Reload then Select Filters";
            this.filterByEventTypesToolStripMenuItem1.Click += new System.EventHandler(this.filterByEventTypesToolStripMenuItem1_Click);
            // 
            // filterByMessageTextToolStripMenuItem1
            // 
            this.filterByMessageTextToolStripMenuItem1.Name = "filterByMessageTextToolStripMenuItem1";
            this.filterByMessageTextToolStripMenuItem1.Size = new System.Drawing.Size(189, 22);
            this.filterByMessageTextToolStripMenuItem1.Text = "Filter by Message Text";
            this.filterByMessageTextToolStripMenuItem1.ToolTipText = "Please First Reload then Select Filters";
            this.filterByMessageTextToolStripMenuItem1.Click += new System.EventHandler(this.filterByMessageTextToolStripMenuItem1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.treeView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(284, 339);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Remote System";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // treeView2
            // 
            this.treeView2.ContextMenuStrip = this.Remote_contextMenuStrip2;
            this.treeView2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.treeView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView2.HideSelection = false;
            this.treeView2.Location = new System.Drawing.Point(3, 3);
            this.treeView2.Name = "treeView2";
            this.treeView2.ShowNodeToolTips = true;
            this.treeView2.Size = new System.Drawing.Size(276, 331);
            this.treeView2.TabIndex = 7;
            this.treeView2.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView2_AfterSelect);
            // 
            // Remote_contextMenuStrip2
            // 
            this.Remote_contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem2,
            this.toolStripSeparator1,
            this.saveThisEventToolStripMenuItem1,
            this.toolStripSeparator5,
            this.filterThisEventToolStripMenuItem});
            this.Remote_contextMenuStrip2.Name = "contextMenuStrip1";
            this.Remote_contextMenuStrip2.Size = new System.Drawing.Size(157, 104);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(156, 22);
            this.toolStripMenuItem3.Text = "Connect";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(156, 22);
            this.toolStripMenuItem2.Text = "Reload";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(153, 6);
            // 
            // saveThisEventToolStripMenuItem1
            // 
            this.saveThisEventToolStripMenuItem1.Name = "saveThisEventToolStripMenuItem1";
            this.saveThisEventToolStripMenuItem1.Size = new System.Drawing.Size(156, 22);
            this.saveThisEventToolStripMenuItem1.Text = "Save This Event";
            this.saveThisEventToolStripMenuItem1.Click += new System.EventHandler(this.saveThisEventToolStripMenuItem1_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(153, 6);
            // 
            // filterThisEventToolStripMenuItem
            // 
            this.filterThisEventToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filterByTypeToolStripMenuItem,
            this.filterByMessageTextToolStripMenuItem2});
            this.filterThisEventToolStripMenuItem.Name = "filterThisEventToolStripMenuItem";
            this.filterThisEventToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.filterThisEventToolStripMenuItem.Text = "Filter This Event";
            // 
            // filterByTypeToolStripMenuItem
            // 
            this.filterByTypeToolStripMenuItem.Name = "filterByTypeToolStripMenuItem";
            this.filterByTypeToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.filterByTypeToolStripMenuItem.Text = "Filter by Event Types";
            this.filterByTypeToolStripMenuItem.Click += new System.EventHandler(this.filterByTypeToolStripMenuItem_Click);
            // 
            // filterByMessageTextToolStripMenuItem2
            // 
            this.filterByMessageTextToolStripMenuItem2.Name = "filterByMessageTextToolStripMenuItem2";
            this.filterByMessageTextToolStripMenuItem2.Size = new System.Drawing.Size(189, 22);
            this.filterByMessageTextToolStripMenuItem2.Text = "Filter by Message Text";
            this.filterByMessageTextToolStripMenuItem2.Click += new System.EventHandler(this.filterByMessageTextToolStripMenuItem2_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.White;
            this.groupBox6.Controls.Add(this.splitContainer3);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(632, 384);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Events and Messages";
            // 
            // splitContainer3
            // 
            this.splitContainer3.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 17);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox5);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox23);
            this.splitContainer3.Size = new System.Drawing.Size(626, 364);
            this.splitContainer3.SplitterDistance = 291;
            this.splitContainer3.TabIndex = 12;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.White;
            this.groupBox5.Controls.Add(this.dataGridView2);
            this.groupBox5.Controls.Add(this.dataGridView3);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(289, 362);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Event Records";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ContextMenuStrip = this.Datagrid1_2ContexMenu;
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 17);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.DarkKhaki;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowCellErrors = false;
            this.dataGridView2.ShowRowErrors = false;
            this.dataGridView2.Size = new System.Drawing.Size(283, 342);
            this.dataGridView2.TabIndex = 3;
            this.dataGridView2.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView2_CellMouseDoubleClick);
            this.dataGridView2.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView2_DataError);
            this.dataGridView2.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_RowEnter);
            // 
            // Datagrid1_2ContexMenu
            // 
            this.Datagrid1_2ContexMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.propertiesToolStripMenuItem});
            this.Datagrid1_2ContexMenu.Name = "Datagrid1_2ContexMenu";
            this.Datagrid1_2ContexMenu.Size = new System.Drawing.Size(128, 26);
            // 
            // propertiesToolStripMenuItem
            // 
            this.propertiesToolStripMenuItem.Name = "propertiesToolStripMenuItem";
            this.propertiesToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.propertiesToolStripMenuItem.Text = "Properties";
            this.propertiesToolStripMenuItem.Click += new System.EventHandler(this.propertiesToolStripMenuItem_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.ContextMenuStrip = this.Datagrid3_4ContexMenu;
            this.dataGridView3.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(3, 17);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.DarkKhaki;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.ShowCellErrors = false;
            this.dataGridView3.ShowRowErrors = false;
            this.dataGridView3.Size = new System.Drawing.Size(283, 342);
            this.dataGridView3.TabIndex = 4;
            this.dataGridView3.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_CellMouseDoubleClick);
            // 
            // Datagrid3_4ContexMenu
            // 
            this.Datagrid3_4ContexMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.propertiesToolStripMenuItem1});
            this.Datagrid3_4ContexMenu.Name = "Datagrid3_4ContexMenu";
            this.Datagrid3_4ContexMenu.Size = new System.Drawing.Size(128, 26);
            // 
            // propertiesToolStripMenuItem1
            // 
            this.propertiesToolStripMenuItem1.Name = "propertiesToolStripMenuItem1";
            this.propertiesToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.propertiesToolStripMenuItem1.Text = "Properties";
            this.propertiesToolStripMenuItem1.Click += new System.EventHandler(this.propertiesToolStripMenuItem1_Click);
            // 
            // groupBox23
            // 
            this.groupBox23.BackColor = System.Drawing.Color.White;
            this.groupBox23.Controls.Add(this.richTextBox1);
            this.groupBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox23.Location = new System.Drawing.Point(0, 0);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(329, 362);
            this.groupBox23.TabIndex = 12;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Event Message";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(3, 17);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(323, 342);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage10);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.ImageList = this.imageList1;
            this.tabControl2.Location = new System.Drawing.Point(0, 25);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(950, 417);
            this.tabControl2.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.splitContainer1);
            this.tabPage3.ImageIndex = 1;
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage3.Size = new System.Drawing.Size(942, 390);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Events";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.tabControl3);
            this.tabPage4.Controls.Add(this.statusStrip2);
            this.tabPage4.ImageIndex = 14;
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage4.Size = new System.Drawing.Size(942, 390);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "MITRE ATT&CK (Search)";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(1, 1);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(938, 364);
            this.tabControl3.TabIndex = 2;
            // 
            // tabPage5
            // 
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Controls.Add(this.splitContainer5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage5.Size = new System.Drawing.Size(930, 338);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "MITRE ATT&CK [ID: ]";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // splitContainer5
            // 
            this.splitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(1, 1);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.splitContainer7);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer5.Size = new System.Drawing.Size(926, 334);
            this.splitContainer5.SplitterDistance = 439;
            this.splitContainer5.TabIndex = 1;
            // 
            // splitContainer7
            // 
            this.splitContainer7.BackColor = System.Drawing.Color.LightGray;
            this.splitContainer7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.groupBox16);
            this.splitContainer7.Panel1.Controls.Add(this.groupBox17);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.groupBox18);
            this.splitContainer7.Panel2.Controls.Add(this.statusStrip3);
            this.splitContainer7.Size = new System.Drawing.Size(439, 334);
            this.splitContainer7.SplitterDistance = 213;
            this.splitContainer7.TabIndex = 1;
            // 
            // groupBox16
            // 
            this.groupBox16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox16.Controls.Add(this.listBox6);
            this.groupBox16.Controls.Add(this.statusStrip9);
            this.groupBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox16.Location = new System.Drawing.Point(0, 0);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(437, 105);
            this.groupBox16.TabIndex = 6;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Technique IDs Name";
            // 
            // listBox6
            // 
            this.listBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(3, 16);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(431, 64);
            this.listBox6.TabIndex = 0;
            this.listBox6.SelectedIndexChanged += new System.EventHandler(this.ListBox6_SelectedIndexChanged);
            // 
            // statusStrip9
            // 
            this.statusStrip9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.statusStrip9.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel11});
            this.statusStrip9.Location = new System.Drawing.Point(3, 80);
            this.statusStrip9.Name = "statusStrip9";
            this.statusStrip9.Size = new System.Drawing.Size(431, 22);
            this.statusStrip9.TabIndex = 2;
            this.statusStrip9.Text = "statusStrip9";
            // 
            // toolStripStatusLabel11
            // 
            this.toolStripStatusLabel11.BackColor = System.Drawing.Color.LightGray;
            this.toolStripStatusLabel11.ForeColor = System.Drawing.Color.Black;
            this.toolStripStatusLabel11.Name = "toolStripStatusLabel11";
            this.toolStripStatusLabel11.Size = new System.Drawing.Size(78, 17);
            this.toolStripStatusLabel11.Text = "SelectedItem:";
            // 
            // groupBox17
            // 
            this.groupBox17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox17.Controls.Add(this.button2);
            this.groupBox17.Controls.Add(this.button13);
            this.groupBox17.Controls.Add(this.button14);
            this.groupBox17.Controls.Add(this.button1);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox17.Location = new System.Drawing.Point(0, 105);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(437, 106);
            this.groupBox17.TabIndex = 7;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Load/Search";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button2.Location = new System.Drawing.Point(3, 11);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(431, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Search (via Powershell)";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button13
            // 
            this.button13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button13.Location = new System.Drawing.Point(3, 34);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(431, 23);
            this.button13.TabIndex = 1;
            this.button13.Text = "Search All Techniques";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // button14
            // 
            this.button14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button14.Location = new System.Drawing.Point(3, 57);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(431, 23);
            this.button14.TabIndex = 2;
            this.button14.Text = "Load MitreAttack (Atomic-Red-Team) yaml Files";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button14_Click);
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.Location = new System.Drawing.Point(3, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(431, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Search Technique";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox18.Controls.Add(this.dataGridView5);
            this.groupBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox18.Location = new System.Drawing.Point(0, 0);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(437, 93);
            this.groupBox18.TabIndex = 8;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Search Results (Events)";
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView5.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 16);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView5.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView5.RowHeadersVisible = false;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.DarkKhaki;
            this.dataGridView5.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView5.Size = new System.Drawing.Size(431, 74);
            this.dataGridView5.TabIndex = 6;
            this.dataGridView5.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView5_RowEnter);
            // 
            // statusStrip3
            // 
            this.statusStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2});
            this.statusStrip3.Location = new System.Drawing.Point(0, 93);
            this.statusStrip3.Name = "statusStrip3";
            this.statusStrip3.Size = new System.Drawing.Size(437, 22);
            this.statusStrip3.TabIndex = 7;
            this.statusStrip3.Text = "statusStrip3";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.Black;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(45, 17);
            this.toolStripStatusLabel2.Text = "Result: ";
            this.toolStripStatusLabel2.TextChanged += new System.EventHandler(this.ToolStripStatusLabel2_TextChanged);
            // 
            // splitContainer6
            // 
            this.splitContainer6.BackColor = System.Drawing.Color.LightGray;
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.groupBox4);
            this.splitContainer6.Size = new System.Drawing.Size(483, 334);
            this.splitContainer6.SplitterDistance = 213;
            this.splitContainer6.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.richTextBox3);
            this.groupBox1.Controls.Add(this.groupBox12);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(481, 211);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MitreAttack (Atomic-Red-Team) yaml File";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox3.Location = new System.Drawing.Point(3, 16);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox3.Size = new System.Drawing.Size(475, 112);
            this.richTextBox3.TabIndex = 0;
            this.richTextBox3.Text = "";
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox12.Controls.Add(this.textBox1);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox12.Location = new System.Drawing.Point(3, 128);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(475, 40);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Type your String/Query for Search (Default Query):";
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(3, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(469, 20);
            this.textBox1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(3, 168);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(475, 40);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Type your String/Query for Search (Second Query):";
            // 
            // textBox3
            // 
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Location = new System.Drawing.Point(3, 16);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(469, 20);
            this.textBox3.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.richTextBox4);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(481, 115);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Event Message";
            // 
            // richTextBox4
            // 
            this.richTextBox4.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.richTextBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox4.Location = new System.Drawing.Point(3, 16);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox4.Size = new System.Drawing.Size(475, 96);
            this.richTextBox4.TabIndex = 0;
            this.richTextBox4.Text = "";
            // 
            // tabPage7
            // 
            this.tabPage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage7.Controls.Add(this.splitContainer4);
            this.tabPage7.Controls.Add(this.statusStrip4);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage7.Size = new System.Drawing.Size(930, 338);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Search History";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(1, 1);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer9);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer8);
            this.splitContainer4.Size = new System.Drawing.Size(926, 312);
            this.splitContainer4.SplitterDistance = 525;
            this.splitContainer4.TabIndex = 1;
            // 
            // splitContainer9
            // 
            this.splitContainer9.BackColor = System.Drawing.Color.LightGray;
            this.splitContainer9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer9.Panel1.Controls.Add(this.groupBox10);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer9.Panel2.Controls.Add(this.groupBox11);
            this.splitContainer9.Size = new System.Drawing.Size(525, 312);
            this.splitContainer9.SplitterDistance = 153;
            this.splitContainer9.TabIndex = 2;
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox10.Controls.Add(this.dataGridView6);
            this.groupBox10.Controls.Add(this.statusStrip5);
            this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox10.Location = new System.Drawing.Point(0, 0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(523, 151);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Last Search Results";
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView6.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 16);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView6.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView6.RowHeadersVisible = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.DarkKhaki;
            this.dataGridView6.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView6.Size = new System.Drawing.Size(517, 110);
            this.dataGridView6.TabIndex = 7;
            // 
            // statusStrip5
            // 
            this.statusStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel5});
            this.statusStrip5.Location = new System.Drawing.Point(3, 126);
            this.statusStrip5.Name = "statusStrip5";
            this.statusStrip5.Size = new System.Drawing.Size(517, 22);
            this.statusStrip5.TabIndex = 8;
            this.statusStrip5.Text = "statusStrip5";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(0, 17);
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox11.Controls.Add(this.listView1);
            this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox11.Location = new System.Drawing.Point(0, 0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(523, 153);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Search History";
            // 
            // listView1
            // 
            this.listView1.ContextMenuStrip = this.contextMenuStrip1;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(3, 16);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(517, 134);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.ListView1_SelectedIndexChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadHistoryToolStripMenuItem1,
            this.saveHistoryToolStripMenuItem1,
            this.clearToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(142, 70);
            // 
            // loadHistoryToolStripMenuItem1
            // 
            this.loadHistoryToolStripMenuItem1.Name = "loadHistoryToolStripMenuItem1";
            this.loadHistoryToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.loadHistoryToolStripMenuItem1.Text = "Load History";
            this.loadHistoryToolStripMenuItem1.Click += new System.EventHandler(this.LoadHistoryToolStripMenuItem1_Click);
            // 
            // saveHistoryToolStripMenuItem1
            // 
            this.saveHistoryToolStripMenuItem1.Name = "saveHistoryToolStripMenuItem1";
            this.saveHistoryToolStripMenuItem1.Size = new System.Drawing.Size(141, 22);
            this.saveHistoryToolStripMenuItem1.Text = "Save History";
            this.saveHistoryToolStripMenuItem1.Click += new System.EventHandler(this.SaveHistoryToolStripMenuItem1_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.ClearToolStripMenuItem_Click);
            // 
            // splitContainer8
            // 
            this.splitContainer8.BackColor = System.Drawing.Color.LightGray;
            this.splitContainer8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.splitContainer8.Panel1.Controls.Add(this.groupBox7);
            this.splitContainer8.Panel1.Controls.Add(this.groupBox13);
            this.splitContainer8.Panel1.Controls.Add(this.groupBox8);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.splitContainer8.Panel2.Controls.Add(this.groupBox9);
            this.splitContainer8.Size = new System.Drawing.Size(397, 312);
            this.splitContainer8.SplitterDistance = 153;
            this.splitContainer8.TabIndex = 2;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.richTextBox5);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(395, 65);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Event Message";
            // 
            // richTextBox5
            // 
            this.richTextBox5.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.richTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox5.Location = new System.Drawing.Point(3, 16);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.ReadOnly = true;
            this.richTextBox5.Size = new System.Drawing.Size(389, 46);
            this.richTextBox5.TabIndex = 1;
            this.richTextBox5.Text = "";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.textBox2);
            this.groupBox13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox13.Location = new System.Drawing.Point(0, 65);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(395, 43);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "First Query";
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(3, 16);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(389, 20);
            this.textBox2.TabIndex = 2;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox4);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox8.Location = new System.Drawing.Point(0, 108);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(395, 43);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Second Query";
            // 
            // textBox4
            // 
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox4.Location = new System.Drawing.Point(3, 16);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(389, 20);
            this.textBox4.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.richTextBox2);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(0, 0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(395, 153);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "MitreAttack (Atomic-Red-Team) yaml File";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.Location = new System.Drawing.Point(3, 16);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(389, 134);
            this.richTextBox2.TabIndex = 0;
            this.richTextBox2.Text = "";
            // 
            // statusStrip4
            // 
            this.statusStrip4.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.statusStrip4.Location = new System.Drawing.Point(1, 313);
            this.statusStrip4.Name = "statusStrip4";
            this.statusStrip4.ShowItemToolTips = true;
            this.statusStrip4.Size = new System.Drawing.Size(926, 22);
            this.statusStrip4.TabIndex = 0;
            this.statusStrip4.Text = "Save Search History";
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip2.Location = new System.Drawing.Point(1, 365);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(938, 22);
            this.statusStrip2.TabIndex = 3;
            this.statusStrip2.Text = "statusStrip2";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(55, 17);
            this.toolStripStatusLabel1.Text = "yaml file:";
            // 
            // tabPage6
            // 
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage6.Controls.Add(this.tabControl4);
            this.tabPage6.ImageIndex = 2;
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage6.Size = new System.Drawing.Size(942, 390);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "MITRE ATT&CK (Real-time)";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage8);
            this.tabControl4.Controls.Add(this.tabPage9);
            this.tabControl4.Controls.Add(this.tabPage40);
            this.tabControl4.Controls.Add(this.tabPage41);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(1, 1);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(938, 386);
            this.tabControl4.TabIndex = 6;
            // 
            // tabPage8
            // 
            this.tabPage8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage8.Controls.Add(this.splitContainer10);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage8.Size = new System.Drawing.Size(930, 360);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "Sysmon (Real-time Events)";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // splitContainer10
            // 
            this.splitContainer10.BackColor = System.Drawing.Color.LightGray;
            this.splitContainer10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.Location = new System.Drawing.Point(1, 1);
            this.splitContainer10.Name = "splitContainer10";
            this.splitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.listView2);
            this.splitContainer10.Panel1.Controls.Add(this.groupBox24);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.splitContainer11);
            this.splitContainer10.Size = new System.Drawing.Size(926, 356);
            this.splitContainer10.SplitterDistance = 175;
            this.splitContainer10.TabIndex = 5;
            // 
            // listView2
            // 
            this.listView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(0, 0);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(924, 94);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.SelectedIndexChanged += new System.EventHandler(this.ListView2_SelectedIndexChanged);
            // 
            // groupBox24
            // 
            this.groupBox24.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox24.Controls.Add(this.richTextBox35);
            this.groupBox24.Controls.Add(this.statusStrip8);
            this.groupBox24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox24.Location = new System.Drawing.Point(0, 94);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox24.Size = new System.Drawing.Size(924, 79);
            this.groupBox24.TabIndex = 6;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Objects Scanned";
            // 
            // richTextBox35
            // 
            this.richTextBox35.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox35.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox35.Location = new System.Drawing.Point(0, 13);
            this.richTextBox35.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox35.Name = "richTextBox35";
            this.richTextBox35.ReadOnly = true;
            this.richTextBox35.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox35.Size = new System.Drawing.Size(924, 44);
            this.richTextBox35.TabIndex = 6;
            this.richTextBox35.Text = "";
            // 
            // statusStrip8
            // 
            this.statusStrip8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.statusStrip8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel10,
            this.toolStripStatusLabel6});
            this.statusStrip8.Location = new System.Drawing.Point(0, 57);
            this.statusStrip8.Name = "statusStrip8";
            this.statusStrip8.Size = new System.Drawing.Size(924, 22);
            this.statusStrip8.TabIndex = 4;
            this.statusStrip8.Text = "statusStrip8";
            // 
            // toolStripStatusLabel10
            // 
            this.toolStripStatusLabel10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel10.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel10.Name = "toolStripStatusLabel10";
            this.toolStripStatusLabel10.Size = new System.Drawing.Size(40, 17);
            this.toolStripStatusLabel10.Text = "Note:";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.BackColor = System.Drawing.Color.Gray;
            this.toolStripStatusLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel6.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(315, 17);
            this.toolStripStatusLabel6.Text = " Real-time Filters: Shows/logs All Detections (Default)";
            // 
            // splitContainer11
            // 
            this.splitContainer11.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.groupBox14);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.groupBox15);
            this.splitContainer11.Size = new System.Drawing.Size(926, 177);
            this.splitContainer11.SplitterDistance = 436;
            this.splitContainer11.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox14.Controls.Add(this.richTextBox6);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(0, 0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(434, 175);
            this.groupBox14.TabIndex = 0;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Event Message";
            // 
            // richTextBox6
            // 
            this.richTextBox6.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.richTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox6.Location = new System.Drawing.Point(3, 16);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.ReadOnly = true;
            this.richTextBox6.Size = new System.Drawing.Size(428, 156);
            this.richTextBox6.TabIndex = 2;
            this.richTextBox6.Text = "";
            // 
            // groupBox15
            // 
            this.groupBox15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox15.Controls.Add(this.richTextBox7);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox15.Location = new System.Drawing.Point(0, 0);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(484, 175);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Details";
            // 
            // richTextBox7
            // 
            this.richTextBox7.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox7.Location = new System.Drawing.Point(3, 16);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.ReadOnly = true;
            this.richTextBox7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox7.Size = new System.Drawing.Size(478, 156);
            this.richTextBox7.TabIndex = 0;
            this.richTextBox7.Text = "";
            // 
            // tabPage9
            // 
            this.tabPage9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage9.Controls.Add(this.groupBox25);
            this.tabPage9.Controls.Add(this.groupBox19);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(930, 360);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "Search Database";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.dataGridView7);
            this.groupBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox25.Location = new System.Drawing.Point(0, 0);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(928, 303);
            this.groupBox25.TabIndex = 9;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Atomic-Red-Team DB, (Last Updated: windows-index.md 22/07/2022)";
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.AllowUserToDeleteRows = false;
            this.dataGridView7.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.dataGridView7.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView7.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(3, 16);
            this.dataGridView7.MultiSelect = false;
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.ReadOnly = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.Peru;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView7.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridView7.RowHeadersVisible = false;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.DarkKhaki;
            this.dataGridView7.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView7.Size = new System.Drawing.Size(922, 284);
            this.dataGridView7.TabIndex = 7;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.button4);
            this.groupBox19.Controls.Add(this.radioButton4);
            this.groupBox19.Controls.Add(this.radioButton3);
            this.groupBox19.Controls.Add(this.radioButton2);
            this.groupBox19.Controls.Add(this.radioButton1);
            this.groupBox19.Controls.Add(this.textBox5);
            this.groupBox19.Controls.Add(this.button3);
            this.groupBox19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox19.Location = new System.Drawing.Point(0, 303);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(928, 55);
            this.groupBox19.TabIndex = 8;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Search";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(845, 14);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 36);
            this.button4.TabIndex = 6;
            this.button4.Text = "Load Database";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(659, 33);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(89, 17);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Record Index";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.RadioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(659, 9);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(77, 17);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Commands";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(568, 33);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(84, 17);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Techique ID";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(568, 9);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(90, 17);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Display Name";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(9, 25);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(553, 20);
            this.textBox5.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(754, 14);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 36);
            this.button3.TabIndex = 0;
            this.button3.Text = "Search";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // tabPage40
            // 
            this.tabPage40.Controls.Add(this.richTextBox36);
            this.tabPage40.Location = new System.Drawing.Point(4, 22);
            this.tabPage40.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage40.Name = "tabPage40";
            this.tabPage40.Size = new System.Drawing.Size(930, 360);
            this.tabPage40.TabIndex = 2;
            this.tabPage40.Text = "Update Database";
            this.tabPage40.UseVisualStyleBackColor = true;
            // 
            // richTextBox36
            // 
            this.richTextBox36.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox36.Location = new System.Drawing.Point(0, 0);
            this.richTextBox36.Name = "richTextBox36";
            this.richTextBox36.ReadOnly = true;
            this.richTextBox36.Size = new System.Drawing.Size(930, 360);
            this.richTextBox36.TabIndex = 0;
            this.richTextBox36.Text = resources.GetString("richTextBox36.Text");
            // 
            // tabPage41
            // 
            this.tabPage41.Controls.Add(this.richTextBox37);
            this.tabPage41.Location = new System.Drawing.Point(4, 22);
            this.tabPage41.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage41.Name = "tabPage41";
            this.tabPage41.Size = new System.Drawing.Size(930, 360);
            this.tabPage41.TabIndex = 3;
            this.tabPage41.Text = "DB Update Logs";
            this.tabPage41.UseVisualStyleBackColor = true;
            // 
            // richTextBox37
            // 
            this.richTextBox37.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox37.Location = new System.Drawing.Point(0, 0);
            this.richTextBox37.Name = "richTextBox37";
            this.richTextBox37.ReadOnly = true;
            this.richTextBox37.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox37.Size = new System.Drawing.Size(930, 360);
            this.richTextBox37.TabIndex = 0;
            this.richTextBox37.Text = "";
            // 
            // tabPage10
            // 
            this.tabPage10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage10.Controls.Add(this.tabControl5);
            this.tabPage10.ImageIndex = 13;
            this.tabPage10.Location = new System.Drawing.Point(4, 23);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(1);
            this.tabPage10.Size = new System.Drawing.Size(942, 390);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "Log Auditing/Respond Analysis (BlueTeam)";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage11);
            this.tabControl5.Controls.Add(this.tabPage12);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Location = new System.Drawing.Point(1, 1);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(938, 386);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage11.Controls.Add(this.splitContainer15);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(930, 360);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "Log Auditing";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // splitContainer15
            // 
            this.splitContainer15.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer15.Location = new System.Drawing.Point(3, 3);
            this.splitContainer15.Name = "splitContainer15";
            // 
            // splitContainer15.Panel1
            // 
            this.splitContainer15.Panel1.Controls.Add(this.treeView4);
            // 
            // splitContainer15.Panel2
            // 
            this.splitContainer15.Panel2.Controls.Add(this.tabControl8);
            this.splitContainer15.Size = new System.Drawing.Size(922, 352);
            this.splitContainer15.SplitterDistance = 218;
            this.splitContainer15.TabIndex = 1;
            // 
            // treeView4
            // 
            this.treeView4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.treeView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView4.Location = new System.Drawing.Point(0, 0);
            this.treeView4.Name = "treeView4";
            this.treeView4.Size = new System.Drawing.Size(216, 350);
            this.treeView4.TabIndex = 1;
            this.treeView4.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeView4_AfterSelect);
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage19);
            this.tabControl8.Controls.Add(this.tabPage26);
            this.tabControl8.Controls.Add(this.tabPage27);
            this.tabControl8.Controls.Add(this.tabPage28);
            this.tabControl8.Controls.Add(this.tabPage29);
            this.tabControl8.Controls.Add(this.tabPage30);
            this.tabControl8.Controls.Add(this.tabPage31);
            this.tabControl8.Controls.Add(this.tabPage32);
            this.tabControl8.Controls.Add(this.tabPage33);
            this.tabControl8.Controls.Add(this.tabPage34);
            this.tabControl8.Controls.Add(this.tabPage35);
            this.tabControl8.Controls.Add(this.tabPage36);
            this.tabControl8.Controls.Add(this.tabPage37);
            this.tabControl8.Controls.Add(this.tabPage38);
            this.tabControl8.Controls.Add(this.tabPage39);
            this.tabControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl8.Location = new System.Drawing.Point(0, 0);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(698, 350);
            this.tabControl8.TabIndex = 1;
            // 
            // tabPage19
            // 
            this.tabPage19.BackColor = System.Drawing.Color.White;
            this.tabPage19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage19.Controls.Add(this.splitContainer12);
            this.tabPage19.Location = new System.Drawing.Point(4, 22);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(690, 324);
            this.tabPage19.TabIndex = 0;
            this.tabPage19.Text = "0.Intrusion EventIDs (Purple Teaming)";
            // 
            // splitContainer12
            // 
            this.splitContainer12.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.Location = new System.Drawing.Point(3, 3);
            this.splitContainer12.Name = "splitContainer12";
            this.splitContainer12.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.splitContainer13);
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.groupBox22);
            this.splitContainer12.Size = new System.Drawing.Size(682, 316);
            this.splitContainer12.SplitterDistance = 155;
            this.splitContainer12.TabIndex = 0;
            // 
            // splitContainer13
            // 
            this.splitContainer13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer13.Location = new System.Drawing.Point(0, 0);
            this.splitContainer13.Name = "splitContainer13";
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.groupBox20);
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.groupBox21);
            this.splitContainer13.Size = new System.Drawing.Size(682, 155);
            this.splitContainer13.SplitterDistance = 379;
            this.splitContainer13.TabIndex = 11;
            // 
            // groupBox20
            // 
            this.groupBox20.BackColor = System.Drawing.Color.White;
            this.groupBox20.Controls.Add(this.dataGridView8);
            this.groupBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox20.Location = new System.Drawing.Point(0, 0);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(377, 153);
            this.groupBox20.TabIndex = 8;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Event IDs";
            // 
            // dataGridView8
            // 
            this.dataGridView8.AllowUserToAddRows = false;
            this.dataGridView8.AllowUserToDeleteRows = false;
            this.dataGridView8.AllowUserToResizeRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            this.dataGridView8.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridView8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView8.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView8.DefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView8.Location = new System.Drawing.Point(3, 16);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.ReadOnly = true;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView8.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridView8.RowHeadersVisible = false;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.Gainsboro;
            this.dataGridView8.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridView8.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView8.Size = new System.Drawing.Size(371, 134);
            this.dataGridView8.TabIndex = 7;
            this.dataGridView8.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView8_RowEnter);
            // 
            // groupBox21
            // 
            this.groupBox21.BackColor = System.Drawing.Color.White;
            this.groupBox21.Controls.Add(this.richTextBox8);
            this.groupBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox21.Location = new System.Drawing.Point(0, 0);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(297, 153);
            this.groupBox21.TabIndex = 10;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "More Information";
            // 
            // richTextBox8
            // 
            this.richTextBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox8.Location = new System.Drawing.Point(3, 16);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.ReadOnly = true;
            this.richTextBox8.Size = new System.Drawing.Size(291, 134);
            this.richTextBox8.TabIndex = 10;
            this.richTextBox8.Text = resources.GetString("richTextBox8.Text");
            // 
            // groupBox22
            // 
            this.groupBox22.BackColor = System.Drawing.Color.White;
            this.groupBox22.Controls.Add(this.richTextBox34);
            this.groupBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox22.Location = new System.Drawing.Point(0, 0);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(682, 157);
            this.groupBox22.TabIndex = 0;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Event Logs";
            // 
            // richTextBox34
            // 
            this.richTextBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox34.Location = new System.Drawing.Point(3, 16);
            this.richTextBox34.Name = "richTextBox34";
            this.richTextBox34.ReadOnly = true;
            this.richTextBox34.Size = new System.Drawing.Size(676, 138);
            this.richTextBox34.TabIndex = 11;
            this.richTextBox34.Text = "";
            // 
            // tabPage26
            // 
            this.tabPage26.BackColor = System.Drawing.Color.White;
            this.tabPage26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage26.Controls.Add(this.richTextBox17);
            this.tabPage26.Location = new System.Drawing.Point(4, 22);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(690, 324);
            this.tabPage26.TabIndex = 1;
            this.tabPage26.Text = "1.Increase Log size to support increased auditing";
            // 
            // richTextBox17
            // 
            this.richTextBox17.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox17.Location = new System.Drawing.Point(3, 3);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.ReadOnly = true;
            this.richTextBox17.Size = new System.Drawing.Size(682, 316);
            this.richTextBox17.TabIndex = 1;
            this.richTextBox17.Text = resources.GetString("richTextBox17.Text");
            // 
            // tabPage27
            // 
            this.tabPage27.BackColor = System.Drawing.Color.White;
            this.tabPage27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage27.Controls.Add(this.richTextBox21);
            this.tabPage27.Location = new System.Drawing.Point(4, 22);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage27.Size = new System.Drawing.Size(690, 324);
            this.tabPage27.TabIndex = 2;
            this.tabPage27.Text = "2.Check settings of Security log";
            // 
            // richTextBox21
            // 
            this.richTextBox21.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox21.Location = new System.Drawing.Point(3, 3);
            this.richTextBox21.Name = "richTextBox21";
            this.richTextBox21.ReadOnly = true;
            this.richTextBox21.Size = new System.Drawing.Size(682, 316);
            this.richTextBox21.TabIndex = 2;
            this.richTextBox21.Text = "C:\\> wevtutil gl Security ";
            // 
            // tabPage28
            // 
            this.tabPage28.BackColor = System.Drawing.Color.White;
            this.tabPage28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage28.Controls.Add(this.richTextBox22);
            this.tabPage28.Location = new System.Drawing.Point(4, 22);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage28.Size = new System.Drawing.Size(690, 324);
            this.tabPage28.TabIndex = 3;
            this.tabPage28.Text = "3.Check settings of audit policies";
            // 
            // richTextBox22
            // 
            this.richTextBox22.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox22.Location = new System.Drawing.Point(3, 3);
            this.richTextBox22.Name = "richTextBox22";
            this.richTextBox22.ReadOnly = true;
            this.richTextBox22.Size = new System.Drawing.Size(682, 316);
            this.richTextBox22.TabIndex = 3;
            this.richTextBox22.Text = "C:\\> auditpol /get /category:* ";
            // 
            // tabPage29
            // 
            this.tabPage29.BackColor = System.Drawing.Color.White;
            this.tabPage29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage29.Controls.Add(this.richTextBox23);
            this.tabPage29.Location = new System.Drawing.Point(4, 22);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage29.Size = new System.Drawing.Size(690, 324);
            this.tabPage29.TabIndex = 4;
            this.tabPage29.Text = "4.Set Log Auditing on for Success/Failure on all Categories: ";
            // 
            // richTextBox23
            // 
            this.richTextBox23.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox23.Location = new System.Drawing.Point(3, 3);
            this.richTextBox23.Name = "richTextBox23";
            this.richTextBox23.ReadOnly = true;
            this.richTextBox23.Size = new System.Drawing.Size(682, 316);
            this.richTextBox23.TabIndex = 3;
            this.richTextBox23.Text = "C:\\> auditpol /set /category:* /success:enable /failure:enable ";
            // 
            // tabPage30
            // 
            this.tabPage30.BackColor = System.Drawing.Color.White;
            this.tabPage30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage30.Controls.Add(this.richTextBox24);
            this.tabPage30.Location = new System.Drawing.Point(4, 22);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage30.Size = new System.Drawing.Size(690, 324);
            this.tabPage30.TabIndex = 5;
            this.tabPage30.Text = "5.Set Log Auditing on for Success/Failure on Subcategories";
            // 
            // richTextBox24
            // 
            this.richTextBox24.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox24.Location = new System.Drawing.Point(3, 3);
            this.richTextBox24.Name = "richTextBox24";
            this.richTextBox24.ReadOnly = true;
            this.richTextBox24.Size = new System.Drawing.Size(682, 316);
            this.richTextBox24.TabIndex = 4;
            this.richTextBox24.Text = resources.GetString("richTextBox24.Text");
            // 
            // tabPage31
            // 
            this.tabPage31.BackColor = System.Drawing.Color.White;
            this.tabPage31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage31.Controls.Add(this.richTextBox25);
            this.tabPage31.Location = new System.Drawing.Point(4, 22);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage31.Size = new System.Drawing.Size(690, 324);
            this.tabPage31.TabIndex = 6;
            this.tabPage31.Text = "6.Account Logon - Audit Credential Validation (Last 14 Days)";
            // 
            // richTextBox25
            // 
            this.richTextBox25.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox25.Location = new System.Drawing.Point(3, 3);
            this.richTextBox25.Name = "richTextBox25";
            this.richTextBox25.ReadOnly = true;
            this.richTextBox25.Size = new System.Drawing.Size(682, 316);
            this.richTextBox25.TabIndex = 5;
            this.richTextBox25.Text = resources.GetString("richTextBox25.Text");
            // 
            // tabPage32
            // 
            this.tabPage32.BackColor = System.Drawing.Color.White;
            this.tabPage32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage32.Controls.Add(this.richTextBox26);
            this.tabPage32.Location = new System.Drawing.Point(4, 22);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage32.Size = new System.Drawing.Size(690, 324);
            this.tabPage32.TabIndex = 7;
            this.tabPage32.Text = "7.Account - Logon/Logoff (Last 14 Days)";
            // 
            // richTextBox26
            // 
            this.richTextBox26.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox26.Location = new System.Drawing.Point(3, 3);
            this.richTextBox26.Name = "richTextBox26";
            this.richTextBox26.ReadOnly = true;
            this.richTextBox26.Size = new System.Drawing.Size(682, 316);
            this.richTextBox26.TabIndex = 6;
            this.richTextBox26.Text = resources.GetString("richTextBox26.Text");
            // 
            // tabPage33
            // 
            this.tabPage33.BackColor = System.Drawing.Color.White;
            this.tabPage33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage33.Controls.Add(this.richTextBox27);
            this.tabPage33.Location = new System.Drawing.Point(4, 22);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage33.Size = new System.Drawing.Size(690, 324);
            this.tabPage33.TabIndex = 8;
            this.tabPage33.Text = "8.Account Management - Audit Application Group Management (Last 14 Days)";
            // 
            // richTextBox27
            // 
            this.richTextBox27.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox27.Location = new System.Drawing.Point(3, 3);
            this.richTextBox27.Name = "richTextBox27";
            this.richTextBox27.ReadOnly = true;
            this.richTextBox27.Size = new System.Drawing.Size(682, 316);
            this.richTextBox27.TabIndex = 7;
            this.richTextBox27.Text = resources.GetString("richTextBox27.Text");
            // 
            // tabPage34
            // 
            this.tabPage34.BackColor = System.Drawing.Color.White;
            this.tabPage34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage34.Controls.Add(this.richTextBox28);
            this.tabPage34.Location = new System.Drawing.Point(4, 22);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage34.Size = new System.Drawing.Size(690, 324);
            this.tabPage34.TabIndex = 9;
            this.tabPage34.Text = "9.Detailed Tracking - Audit DPAPI Activity/Process Termination/RPC Events:";
            // 
            // richTextBox28
            // 
            this.richTextBox28.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox28.Location = new System.Drawing.Point(3, 3);
            this.richTextBox28.Name = "richTextBox28";
            this.richTextBox28.ReadOnly = true;
            this.richTextBox28.Size = new System.Drawing.Size(682, 316);
            this.richTextBox28.TabIndex = 8;
            this.richTextBox28.Text = resources.GetString("richTextBox28.Text");
            // 
            // tabPage35
            // 
            this.tabPage35.BackColor = System.Drawing.Color.White;
            this.tabPage35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage35.Controls.Add(this.richTextBox29);
            this.tabPage35.Location = new System.Drawing.Point(4, 22);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage35.Size = new System.Drawing.Size(690, 324);
            this.tabPage35.TabIndex = 10;
            this.tabPage35.Text = "10.Audit Directory Service Access (Last 14 Days)";
            // 
            // richTextBox29
            // 
            this.richTextBox29.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox29.Location = new System.Drawing.Point(3, 3);
            this.richTextBox29.Name = "richTextBox29";
            this.richTextBox29.ReadOnly = true;
            this.richTextBox29.Size = new System.Drawing.Size(682, 316);
            this.richTextBox29.TabIndex = 9;
            this.richTextBox29.Text = resources.GetString("richTextBox29.Text");
            // 
            // tabPage36
            // 
            this.tabPage36.BackColor = System.Drawing.Color.White;
            this.tabPage36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage36.Controls.Add(this.richTextBox30);
            this.tabPage36.Location = new System.Drawing.Point(4, 22);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage36.Size = new System.Drawing.Size(690, 324);
            this.tabPage36.TabIndex = 11;
            this.tabPage36.Text = "11.Object Access - Audit File Share, File System, SAM, Registry, Certifications";
            // 
            // richTextBox30
            // 
            this.richTextBox30.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox30.Location = new System.Drawing.Point(3, 3);
            this.richTextBox30.Name = "richTextBox30";
            this.richTextBox30.ReadOnly = true;
            this.richTextBox30.Size = new System.Drawing.Size(682, 316);
            this.richTextBox30.TabIndex = 10;
            this.richTextBox30.Text = resources.GetString("richTextBox30.Text");
            // 
            // tabPage37
            // 
            this.tabPage37.BackColor = System.Drawing.Color.White;
            this.tabPage37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage37.Controls.Add(this.richTextBox31);
            this.tabPage37.Location = new System.Drawing.Point(4, 22);
            this.tabPage37.Name = "tabPage37";
            this.tabPage37.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage37.Size = new System.Drawing.Size(690, 324);
            this.tabPage37.TabIndex = 12;
            this.tabPage37.Text = "12.Audit Policy Change, Microsoft Protection Service, Windows Filtering Platform";
            // 
            // richTextBox31
            // 
            this.richTextBox31.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox31.Location = new System.Drawing.Point(3, 3);
            this.richTextBox31.Name = "richTextBox31";
            this.richTextBox31.ReadOnly = true;
            this.richTextBox31.Size = new System.Drawing.Size(682, 316);
            this.richTextBox31.TabIndex = 11;
            this.richTextBox31.Text = resources.GetString("richTextBox31.Text");
            // 
            // tabPage38
            // 
            this.tabPage38.BackColor = System.Drawing.Color.White;
            this.tabPage38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage38.Controls.Add(this.richTextBox32);
            this.tabPage38.Location = new System.Drawing.Point(4, 22);
            this.tabPage38.Name = "tabPage38";
            this.tabPage38.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage38.Size = new System.Drawing.Size(690, 324);
            this.tabPage38.TabIndex = 13;
            this.tabPage38.Text = "13.Audit Non-Sensitive/Sensitive Privilege Use";
            // 
            // richTextBox32
            // 
            this.richTextBox32.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox32.Location = new System.Drawing.Point(3, 3);
            this.richTextBox32.Name = "richTextBox32";
            this.richTextBox32.ReadOnly = true;
            this.richTextBox32.Size = new System.Drawing.Size(682, 316);
            this.richTextBox32.TabIndex = 10;
            this.richTextBox32.Text = resources.GetString("richTextBox32.Text");
            // 
            // tabPage39
            // 
            this.tabPage39.BackColor = System.Drawing.Color.White;
            this.tabPage39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage39.Controls.Add(this.richTextBox33);
            this.tabPage39.Location = new System.Drawing.Point(4, 22);
            this.tabPage39.Name = "tabPage39";
            this.tabPage39.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage39.Size = new System.Drawing.Size(690, 324);
            this.tabPage39.TabIndex = 14;
            this.tabPage39.Text = "14.Audit Security State Change, Security System Extension, System Integrity, Syst" +
    "em Events";
            // 
            // richTextBox33
            // 
            this.richTextBox33.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox33.Location = new System.Drawing.Point(3, 3);
            this.richTextBox33.Name = "richTextBox33";
            this.richTextBox33.ReadOnly = true;
            this.richTextBox33.Size = new System.Drawing.Size(682, 316);
            this.richTextBox33.TabIndex = 11;
            this.richTextBox33.Text = resources.GetString("richTextBox33.Text");
            // 
            // tabPage12
            // 
            this.tabPage12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage12.Controls.Add(this.splitContainer14);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(930, 360);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "Respond Analysis";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // splitContainer14
            // 
            this.splitContainer14.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer14.Location = new System.Drawing.Point(3, 3);
            this.splitContainer14.Name = "splitContainer14";
            // 
            // splitContainer14.Panel1
            // 
            this.splitContainer14.Panel1.Controls.Add(this.treeView3);
            // 
            // splitContainer14.Panel2
            // 
            this.splitContainer14.Panel2.Controls.Add(this.tabControl6);
            this.splitContainer14.Size = new System.Drawing.Size(922, 352);
            this.splitContainer14.SplitterDistance = 220;
            this.splitContainer14.TabIndex = 1;
            // 
            // treeView3
            // 
            this.treeView3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.treeView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView3.Location = new System.Drawing.Point(0, 0);
            this.treeView3.Name = "treeView3";
            this.treeView3.Size = new System.Drawing.Size(218, 350);
            this.treeView3.TabIndex = 0;
            this.treeView3.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeView3_AfterSelect);
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage24);
            this.tabControl6.Controls.Add(this.tabPage13);
            this.tabControl6.Controls.Add(this.tabPage14);
            this.tabControl6.Controls.Add(this.tabPage15);
            this.tabControl6.Controls.Add(this.tabPage16);
            this.tabControl6.Controls.Add(this.tabPage17);
            this.tabControl6.Controls.Add(this.tabPage18);
            this.tabControl6.Controls.Add(this.tabPage20);
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl6.Location = new System.Drawing.Point(0, 0);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(696, 350);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage24
            // 
            this.tabPage24.BackColor = System.Drawing.Color.White;
            this.tabPage24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage24.Controls.Add(this.richTextBox9);
            this.tabPage24.Location = new System.Drawing.Point(4, 22);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(688, 324);
            this.tabPage24.TabIndex = 8;
            this.tabPage24.Text = "0.Logs";
            // 
            // richTextBox9
            // 
            this.richTextBox9.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox9.Location = new System.Drawing.Point(3, 3);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.ReadOnly = true;
            this.richTextBox9.Size = new System.Drawing.Size(680, 316);
            this.richTextBox9.TabIndex = 0;
            this.richTextBox9.Text = resources.GetString("richTextBox9.Text");
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.White;
            this.tabPage13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage13.Controls.Add(this.richTextBox11);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(688, 324);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "1.System Information ";
            // 
            // richTextBox11
            // 
            this.richTextBox11.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox11.Location = new System.Drawing.Point(3, 3);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(680, 316);
            this.richTextBox11.TabIndex = 0;
            this.richTextBox11.Text = resources.GetString("richTextBox11.Text");
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.White;
            this.tabPage14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage14.Controls.Add(this.richTextBox12);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(688, 324);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "2.User Information";
            // 
            // richTextBox12
            // 
            this.richTextBox12.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox12.Location = new System.Drawing.Point(3, 3);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.ReadOnly = true;
            this.richTextBox12.Size = new System.Drawing.Size(680, 316);
            this.richTextBox12.TabIndex = 1;
            this.richTextBox12.Text = resources.GetString("richTextBox12.Text");
            // 
            // tabPage15
            // 
            this.tabPage15.BackColor = System.Drawing.Color.White;
            this.tabPage15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage15.Controls.Add(this.richTextBox13);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(688, 324);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "3.Network Information";
            // 
            // richTextBox13
            // 
            this.richTextBox13.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox13.Location = new System.Drawing.Point(3, 3);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.ReadOnly = true;
            this.richTextBox13.Size = new System.Drawing.Size(680, 316);
            this.richTextBox13.TabIndex = 1;
            this.richTextBox13.Text = resources.GetString("richTextBox13.Text");
            // 
            // tabPage16
            // 
            this.tabPage16.BackColor = System.Drawing.Color.White;
            this.tabPage16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage16.Controls.Add(this.richTextBox14);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(688, 324);
            this.tabPage16.TabIndex = 3;
            this.tabPage16.Text = "4.Service Information";
            // 
            // richTextBox14
            // 
            this.richTextBox14.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox14.Location = new System.Drawing.Point(3, 3);
            this.richTextBox14.Name = "richTextBox14";
            this.richTextBox14.ReadOnly = true;
            this.richTextBox14.Size = new System.Drawing.Size(680, 316);
            this.richTextBox14.TabIndex = 2;
            this.richTextBox14.Text = resources.GetString("richTextBox14.Text");
            // 
            // tabPage17
            // 
            this.tabPage17.BackColor = System.Drawing.Color.White;
            this.tabPage17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage17.Controls.Add(this.richTextBox15);
            this.tabPage17.Location = new System.Drawing.Point(4, 22);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(688, 324);
            this.tabPage17.TabIndex = 4;
            this.tabPage17.Text = "5.Policy/Patch/Settings Information";
            // 
            // richTextBox15
            // 
            this.richTextBox15.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox15.Location = new System.Drawing.Point(3, 3);
            this.richTextBox15.Name = "richTextBox15";
            this.richTextBox15.ReadOnly = true;
            this.richTextBox15.Size = new System.Drawing.Size(680, 316);
            this.richTextBox15.TabIndex = 3;
            this.richTextBox15.Text = resources.GetString("richTextBox15.Text");
            // 
            // tabPage18
            // 
            this.tabPage18.BackColor = System.Drawing.Color.White;
            this.tabPage18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage18.Controls.Add(this.richTextBox16);
            this.tabPage18.Location = new System.Drawing.Point(4, 22);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(688, 324);
            this.tabPage18.TabIndex = 5;
            this.tabPage18.Text = "6.AutoRun/AutoLoad Information";
            // 
            // richTextBox16
            // 
            this.richTextBox16.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox16.Location = new System.Drawing.Point(3, 3);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.ReadOnly = true;
            this.richTextBox16.Size = new System.Drawing.Size(680, 316);
            this.richTextBox16.TabIndex = 4;
            this.richTextBox16.Text = resources.GetString("richTextBox16.Text");
            // 
            // tabPage20
            // 
            this.tabPage20.BackColor = System.Drawing.Color.White;
            this.tabPage20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage20.Controls.Add(this.tabControl7);
            this.tabPage20.Location = new System.Drawing.Point(4, 22);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(688, 324);
            this.tabPage20.TabIndex = 7;
            this.tabPage20.Text = "7.Registry Information (AutoRun)";
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage21);
            this.tabControl7.Controls.Add(this.tabPage22);
            this.tabControl7.Controls.Add(this.tabPage23);
            this.tabControl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl7.Location = new System.Drawing.Point(3, 3);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(680, 316);
            this.tabControl7.TabIndex = 0;
            // 
            // tabPage21
            // 
            this.tabPage21.BackColor = System.Drawing.Color.White;
            this.tabPage21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage21.Controls.Add(this.richTextBox18);
            this.tabPage21.Location = new System.Drawing.Point(4, 22);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(672, 290);
            this.tabPage21.TabIndex = 0;
            this.tabPage21.Text = "7-1.HKEY_CLASSES_ROOT";
            // 
            // richTextBox18
            // 
            this.richTextBox18.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox18.Location = new System.Drawing.Point(3, 3);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.ReadOnly = true;
            this.richTextBox18.Size = new System.Drawing.Size(664, 282);
            this.richTextBox18.TabIndex = 6;
            this.richTextBox18.Text = resources.GetString("richTextBox18.Text");
            // 
            // tabPage22
            // 
            this.tabPage22.BackColor = System.Drawing.Color.White;
            this.tabPage22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage22.Controls.Add(this.richTextBox19);
            this.tabPage22.Location = new System.Drawing.Point(4, 22);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(672, 290);
            this.tabPage22.TabIndex = 1;
            this.tabPage22.Text = "7-2.HKEY_CURRENT_USERS";
            // 
            // richTextBox19
            // 
            this.richTextBox19.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox19.Location = new System.Drawing.Point(3, 3);
            this.richTextBox19.Name = "richTextBox19";
            this.richTextBox19.ReadOnly = true;
            this.richTextBox19.Size = new System.Drawing.Size(664, 282);
            this.richTextBox19.TabIndex = 6;
            this.richTextBox19.Text = resources.GetString("richTextBox19.Text");
            // 
            // tabPage23
            // 
            this.tabPage23.BackColor = System.Drawing.Color.White;
            this.tabPage23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage23.Controls.Add(this.richTextBox20);
            this.tabPage23.Location = new System.Drawing.Point(4, 22);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(672, 290);
            this.tabPage23.TabIndex = 2;
            this.tabPage23.Text = "7-3.HKEY_LOCAL_MACHINE";
            // 
            // richTextBox20
            // 
            this.richTextBox20.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox20.Location = new System.Drawing.Point(3, 3);
            this.richTextBox20.Name = "richTextBox20";
            this.richTextBox20.ReadOnly = true;
            this.richTextBox20.Size = new System.Drawing.Size(664, 282);
            this.richTextBox20.TabIndex = 6;
            this.richTextBox20.Text = resources.GetString("richTextBox20.Text");
            // 
            // tabPage25
            // 
            this.tabPage25.BackColor = System.Drawing.Color.White;
            this.tabPage25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage25.Controls.Add(this.richTextBox10);
            this.tabPage25.Location = new System.Drawing.Point(4, 22);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(688, 324);
            this.tabPage25.TabIndex = 9;
            this.tabPage25.Text = "8.File/Drivers/Shares Information";
            // 
            // richTextBox10
            // 
            this.richTextBox10.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox10.Location = new System.Drawing.Point(3, 3);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.ReadOnly = true;
            this.richTextBox10.Size = new System.Drawing.Size(680, 316);
            this.richTextBox10.TabIndex = 0;
            this.richTextBox10.Text = resources.GetString("richTextBox10.Text");
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "icons8-warning-48.png");
            this.imageList1.Images.SetKeyName(1, "icons8-event-log-48.png");
            this.imageList1.Images.SetKeyName(2, "process_thealert_2342.png");
            this.imageList1.Images.SetKeyName(3, "process-accept_icon-icons.com_52369.png");
            this.imageList1.Images.SetKeyName(4, "Ampeross-Qetto-2-Check.ico");
            this.imageList1.Images.SetKeyName(5, "Awicons-Vista-Artistic-Add.ico");
            this.imageList1.Images.SetKeyName(6, "Awicons-Vista-Artistic-Delete.ico");
            this.imageList1.Images.SetKeyName(7, "Danrabbit-Elementary-Button-stop.ico");
            this.imageList1.Images.SetKeyName(8, "Graphicloads-100-Flat-2-Check-1.ico");
            this.imageList1.Images.SetKeyName(9, "Icojam-Blueberry-Basic-Shield-protect-off.ico");
            this.imageList1.Images.SetKeyName(10, "Icojam-Blueberry-Basic-Shield-protect-on.ico");
            this.imageList1.Images.SetKeyName(11, "Matiasam-Ios7-Style-Clear-Tick.ico");
            this.imageList1.Images.SetKeyName(12, "Saki-NuoveXT-2-Actions-remove.ico");
            this.imageList1.Images.SetKeyName(13, "icons8-logs-64.png");
            this.imageList1.Images.SetKeyName(14, "icons8-event-log-96.png");
            this.imageList1.Images.SetKeyName(15, "icons8-logs-flaticons-lineal-color-96.png");
            // 
            // loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem
            // 
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Name = "loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStr" +
    "ipMenuItem";
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Size = new System.Drawing.Size(621, 22);
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Text = "Load All CmdPrompts + Make Simple_Text_DB_File.txt (via Atomic-Red-Team [Windows-" +
    "Index.md] File)";
            this.loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem.Click += new System.EventHandler(this.LoadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 464);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(966, 503);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BEV 4";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.Local_contextMenuStrip1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.Remote_contextMenuStrip2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.Datagrid1_2ContexMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.Datagrid3_4ContexMenu.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.statusStrip9.ResumeLayout(false);
            this.statusStrip9.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.statusStrip3.ResumeLayout(false);
            this.statusStrip3.PerformLayout();
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.statusStrip5.ResumeLayout(false);
            this.statusStrip5.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.statusStrip8.ResumeLayout(false);
            this.statusStrip8.PerformLayout();
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.tabPage40.ResumeLayout(false);
            this.tabPage41.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.splitContainer15.Panel1.ResumeLayout(false);
            this.splitContainer15.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer15)).EndInit();
            this.splitContainer15.ResumeLayout(false);
            this.tabControl8.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).EndInit();
            this.splitContainer13.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.groupBox21.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.tabPage26.ResumeLayout(false);
            this.tabPage27.ResumeLayout(false);
            this.tabPage28.ResumeLayout(false);
            this.tabPage29.ResumeLayout(false);
            this.tabPage30.ResumeLayout(false);
            this.tabPage31.ResumeLayout(false);
            this.tabPage32.ResumeLayout(false);
            this.tabPage33.ResumeLayout(false);
            this.tabPage34.ResumeLayout(false);
            this.tabPage35.ResumeLayout(false);
            this.tabPage36.ResumeLayout(false);
            this.tabPage37.ResumeLayout(false);
            this.tabPage38.ResumeLayout(false);
            this.tabPage39.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.splitContainer14.Panel1.ResumeLayout(false);
            this.splitContainer14.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer14)).EndInit();
            this.splitContainer14.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage24.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage18.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tabControl7.ResumeLayout(false);
            this.tabPage21.ResumeLayout(false);
            this.tabPage22.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.tabPage25.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TreeView treeView2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem relaodToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem filterByEventTypesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filterByMessageTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherFiltersToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton4;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutBEVToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton5;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_Nodes;
        private System.Windows.Forms.ToolStripMenuItem reloadToolStripMenuItem;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem remoteToolStripMenuItem;
        public System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.ContextMenuStrip Local_contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reloadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip Remote_contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem saveThisEventToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveThisEventToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem filteringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filterByEventTypesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem filterByMessageTextToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip Datagrid1_2ContexMenu;
        private System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip Datagrid3_4ContexMenu;
        private System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem filterThisEventToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filterByTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filterByMessageTextToolStripMenuItem2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton6;
        private System.Windows.Forms.ToolStripMenuItem propertiesWindowToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip statusStrip3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.StatusStrip statusStrip4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        public System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.StatusStrip statusStrip5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton7;
        private System.Windows.Forms.ToolStripMenuItem startRealtimeMonitorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopMonitorToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel9;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.TabPage tabPage9;
        public System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ToolStripMenuItem realtimeScanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scanningFastToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scanningArgsSlowToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel10;
        private System.Windows.Forms.StatusStrip statusStrip9;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem loadCMDPromptsFromAllYamlFilesIntoTextFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem searchHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadHistoryToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem loadHistoryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveHistoryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        public System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.SplitContainer splitContainer13;
        private System.Windows.Forms.GroupBox groupBox20;
        public System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.SplitContainer splitContainer14;
        private System.Windows.Forms.TreeView treeView3;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.RichTextBox richTextBox14;
        private System.Windows.Forms.RichTextBox richTextBox15;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.RichTextBox richTextBox19;
        private System.Windows.Forms.RichTextBox richTextBox20;
        private System.Windows.Forms.SplitContainer splitContainer15;
        private System.Windows.Forms.TreeView treeView4;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.RichTextBox richTextBox21;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.RichTextBox richTextBox22;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.RichTextBox richTextBox23;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.RichTextBox richTextBox24;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.RichTextBox richTextBox25;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.RichTextBox richTextBox26;
        private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.RichTextBox richTextBox27;
        private System.Windows.Forms.TabPage tabPage34;
        private System.Windows.Forms.RichTextBox richTextBox28;
        private System.Windows.Forms.TabPage tabPage35;
        private System.Windows.Forms.RichTextBox richTextBox29;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.RichTextBox richTextBox30;
        private System.Windows.Forms.TabPage tabPage37;
        private System.Windows.Forms.RichTextBox richTextBox31;
        private System.Windows.Forms.TabPage tabPage38;
        private System.Windows.Forms.RichTextBox richTextBox32;
        private System.Windows.Forms.TabPage tabPage39;
        private System.Windows.Forms.RichTextBox richTextBox33;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reloadExportToHTMLCSVViaPowershellToolStripMenuItem;
        private System.Windows.Forms.RichTextBox richTextBox34;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.RichTextBox richTextBox35;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.TabPage tabPage40;
        private System.Windows.Forms.RichTextBox richTextBox36;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton8;
        private System.Windows.Forms.ToolStripMenuItem updateDatabaseviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem updateDatabaseviaYourOwnYamlFileToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage41;
        private System.Windows.Forms.RichTextBox richTextBox37;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem logsOnlyTruePositivesNotRecommandedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showsLogsOnlyFalsePositiveDetectionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showLogsAllDetectionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripMenuItem loadAllCmdPromptsMakeSimpleTextDBFiletxtviaAtomicRedTeamWindowsIndexmdFileToolStripMenuItem;
    }
}

