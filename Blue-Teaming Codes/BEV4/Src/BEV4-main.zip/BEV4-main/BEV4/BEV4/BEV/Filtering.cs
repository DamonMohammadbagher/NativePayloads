﻿namespace BEV
{
    internal class Filtering
    {
    }
}