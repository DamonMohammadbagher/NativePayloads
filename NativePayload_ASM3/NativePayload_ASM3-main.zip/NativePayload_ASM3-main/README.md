# NativePayload_ASM3

### NativePayload_ASM3/AsynASM , Injecting Meterpreter Payload bytes into local Process via Delegation Technique + in-memory with delay Changing RWX to X [Bypassing AVs]

Note: Code was created in [Jun/Feb 2023] and some AVs bypassed by this simple code for more info watch video.

Related Video [NativePayload_AsynASM]: https://www.linkedin.com/posts/damonmohammadbagher_bypassing-redteaming-pentesting-activity-7031685536918458369-U9XY

Related Video [NativePayload_ASM]: https://www.youtube.com/watch?v=T57pWzS59Y8 

Usage: 
    
     NativePayload_ASM3.exe "meterpreter/cobaltstrike payload"
     example: NativePayload_ASM3.exe "fc,48,e8,00,....."
     
Usage: 
    
     NativePayload_AsynASM.exe "meterpreter/cobaltstrike payload"
     example: NativePayload_AsynASM.exe "fc,48,e8,00,....."     

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_ASM3/"/></a></p>
