# NativePayload_DynLCI
NativePayload_DynLCI , Dynamic Local Code Invoke , Injecting Meterpreter Payload bytes into local Process

Simple C# code for Dynamic Injecting Codes from command-prompt Argument into local Process and Dynamic Invoke payload in-memory....

Usage: 
    
     NativePayload_DynLCI.exe "meterpreter/cobaltstrike payload"
     example: NativePayload_DynLCI.exe "fc.48.e8,00,....."
     
     
     
      
   
   
 <p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_DynLCI"/></a></p>
