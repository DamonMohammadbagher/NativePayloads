# NativePayload_BSSID
Transferring Backdoor Payload by BSSID and Wireless traffic

Published by Damon Mohammadbagher


Syntax : NativePayload_BSSID.exe  help

Syntax : NativePayload_BSSID.exe  null  "payload string"

Syntax : NativePayload_BSSID.exe  "ESSID"


For Step by step you should visit one of these links:

link1 : https://www.linkedin.com/pulse/transferring-backdoor-payloads-bssid-wireless-traffic-mohammadbagher

link2 : https://www.peerlyst.com/posts/transferring-backdoor-payloads-with-bssid-by-wireless-traffic-damon-mohammadbagher

Video : https://youtu.be/W0dJGln3tls


Note : C# Source Code for  "managedwifi.dll"  is 

link : https://managedwifi.codeplex.com/SourceControl/latest


if you want , you can Download this C# Source Code and make your own dll file its better than using this "managedwifi.dll" in github ...

but this file is ok .... i hope ;)

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_BSSID/"/></a></p>
