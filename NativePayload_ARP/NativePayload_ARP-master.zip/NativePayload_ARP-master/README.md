# NativePayload_ARP
C# code for Backdoor Payloads transfer by ARP Traffic (Slow)

also Bypassing the most Anti-viruses by this technique 

2 Bug Fixed: bug for NativePayload_ARP fixed by adding new code ;).

############################### Warning ###########################

Warning this Acc maybe Hacked by someone ;-(

someone changed my source code for NativePayload_ARP ( 3 times ) and changed my exe files too , ;) , so EXE files deleted by me , just make your own code by this article , it is better than executing my EXE files
just watching my Source code and my Article about this "PoC" and create your own Code please.

linkedin link : https://www.linkedin.com/pulse/transfer-backdoor-payloads-arp-traffic-bypassing-avs-mohammadbagher?trk=pulse_spock-articles

link 2 , step by step PoC: https://www.peerlyst.com/posts/transfer-backdoor-payloads-by-arp-traffic-and-bypassing-avs-damon-mohammadbagher?trk=user_notification#undefined

############################### Warning ###########################

with this technique you can transfer your payloads by ARP traffic

but this method is not fast ;-)

for step by step please visit this link :

link : https://www.peerlyst.com/posts/transfer-backdoor-payloads-by-arp-traffic-and-bypassing-avs-damon-mohammadbagher

Transfer Backdoor Payloads by ARP Traffic

video : https://youtu.be/qDLicXj7Vuk

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_ARP"/></a></p>
