this C# source code customized to working by Macchanger command in linux base systems

so this NativePayload_ARP supported macchanger command in linux and in this case not needed to use Payload_to_Mac.exe .

and you can use Macchanger command in linux for sending your payloads by ARP traffic from Linux based system to Backdoor (NativePayload_ARP.exe)


you can use macchanger tool to sending Payloads by ARP traffic like this file ==> Macchange.sh 
