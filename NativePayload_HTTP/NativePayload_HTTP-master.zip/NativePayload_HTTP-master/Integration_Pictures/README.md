         old technique but useful , in this case my code Injected to cmd Process by "NativePayload_CSI.exe" (Client-side)
         and Backdoor/Shell connected to server via HTTP Traffic also Shell output Injected 
         to HTTP Header fields.... 
         Note: in this case "NativePayload_HTTP.sh" is (Server-side) tool ;)
         Video : https://www.youtube.com/watch?v=wwMf2sg1XW0
         
